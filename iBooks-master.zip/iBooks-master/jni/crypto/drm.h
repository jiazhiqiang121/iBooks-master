#include <string>
using namespace std;

#ifndef _Included_DRM
#define _Included_DRM
#ifdef __cplusplus
extern "C" {
#endif

	string drm_digest(string mixed);

#ifdef __cplusplus
}
#endif
#endif
