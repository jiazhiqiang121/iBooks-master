#include <iostream>
#include <cstring>
using namespace std;

#ifndef _Included_SHA1
#define _Included_SHA1
#ifdef __cplusplus
extern "C" {
#endif

string getSHA1(string s);

#ifdef __cplusplus
}
#endif
#endif
