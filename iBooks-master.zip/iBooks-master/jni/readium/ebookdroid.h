#ifndef EBOOKDROID_H
#define EBOOKDROID_H

#include <jni.h>

#ifdef __cplusplus
extern "C"
{
#endif

int getDescriptor(JNIEnv *env, jobject fd)


#ifdef __cplusplus
}
#endif

#endif
